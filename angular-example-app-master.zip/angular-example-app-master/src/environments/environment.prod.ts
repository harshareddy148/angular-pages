export const environment = {
  production: true,
  baseUrl: 'https://ismaestro.github.io/angular-example-app',
  graphqlHost: 'https://nestjs-example-app.herokuapp.com/',
};
