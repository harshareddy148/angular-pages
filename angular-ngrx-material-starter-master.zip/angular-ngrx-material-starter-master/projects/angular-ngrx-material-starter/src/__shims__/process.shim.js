const process = {
  env: {
    // eslint-disable-next-line @typescript-eslint/naming-convention
    NODE_ENV: 'test'
  }
};
