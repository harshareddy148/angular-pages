export interface AuthState {
  isAuthenticated: boolean;
}
